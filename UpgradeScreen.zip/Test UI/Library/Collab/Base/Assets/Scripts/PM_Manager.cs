﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace PMManager{

public class PM_Manager : MonoBehaviour {
		public Canvas TestCanvas;
		public Image SpeedBar, DamageBar, AmorBar, DescBox;
		public Text Description, ShipTitle;

		int points=0;//for purchasing
		int upgrade=0;//upgrade selected

		//@TODO: May need to assign all buttons numbers in an array 0-9
			public int cost;
			public int[] number;
			public string[] descriptions = new string[9];
			public string[] titles = new string[9];//number of upgrade 1-10



	// Use this for initialization
	void Start () {
		//For upgrade test

			descriptions[0] = "Please press an upgrade to view description";
			descriptions[1] = "Test ship one";
			descriptions[2] = "Test ship two";

			titles[0] = "No Title To Display";
			titles[1] = "Ship 1";
			titles[2] = "Ship 2";

		//End test
		
		
	}

		//Button functions

		public void Select(){
			//Which button is selected, will be the numbered upgrade to be displayed
			//Test button upgrade
			int number=1;
			Debug.Log ("Button " + number + " has been pressed");
			ShowInfo (number);

			//End test
		}

		public void Back(){
			//Go back to previous screen
		}

		public void Buy(){
			//purchase function--will do reset the meter back to empty
		}

		public void Execute(){
			//play game
		}

		void ShowInfo(int n){ //shows the info of the upgrade in the upgrade box
			Description.text=descriptions[n];
			ShipTitle.text = titles [n];
			//int number = button number

			//Description = ui.desc[n];
		}



	// Update is called once per frame
	void Update () {
		
	}
}

}
